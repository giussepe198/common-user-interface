/**
 * Regional date and time conventions for display and entry.
 * All regions display DD-Mmm-YYYY on screen and HH:mm on the 24-hour clock with a colon.
 */
import type { ClinicalRegion } from '../../../core/locale';

/**
 * Day-of-week abbreviations, Sunday first (JavaScript getDay order).
 * GB: CUI D+Ta-0016 (Mon Tue Wed Thu Fri Sat Sun).
 * AU: ACSQHC Recommendations for safe use of medicines terminology (Nov 2024), accepted terms
 *     "Mon, Tue, Wed, Thur, Fri, Sat, Sun" (note Thur). G10 AU-DT-04.
 *     https://www.safetyandquality.gov.au/sites/default/files/2024-12/recommendations-for-safe-use-of-medicines-terminology.pdf
 * NZ: no NZ source found; CUI set kept (G11 7.1).
 */
export const DAY_ABBREVIATIONS: Record<ClinicalRegion, readonly string[]> = {
  GB: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
  AU: ['Sun', 'Mon', 'Tue', 'Wed', 'Thur', 'Fri', 'Sat'],
  NZ: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
};

/**
 * How numeric dates such as 05/04/2009 are read.
 * GB: "ask" (CUI D+Tc-0005: offer 05-Apr-2009 or 04-May-2009).
 * AU: "dayFirst": AU-DT-01, day precedes month in every format; never MM/DD/YYYY (G10 8.1).
 * NZ: "dayFirst": accept DD/MM/YYYY and D/M/YYYY, never MM/DD/YYYY (G11 7.1; HQSC NMC user guide 2021
 *     https://www.hqsc.govt.nz/assets/Our-work/System-safety/Reducing-harm/Medicines/Publications-resources/NMC_user_guide_update_2021.pdf).
 */
export const NUMERIC_DATE_ORDER: Record<ClinicalRegion, 'ask' | 'dayFirst'> = {
  GB: 'ask',
  AU: 'dayFirst',
  NZ: 'dayFirst',
};

/** Day abbreviation for a getDay() index in the region, e.g. AU 4 gives "Thur". */
export function regionalDayAbbreviation(day: number, region: ClinicalRegion = 'GB'): string {
  return DAY_ABBREVIATIONS[region][day];
}
