import { describe, expect, it } from 'vitest';
import {
  EncodableMatch,
  adjustMatchesForEdit,
  diffTextEdit,
  editTouchesConfirmed,
  matchAtCaret,
  nextWordEnd,
  previousWordEnd,
  segmentEncodableText,
} from './encodable';

const text = 'mild fever for three days';
const matches: EncodableMatch[] = [
  { id: 'a', start: 0, end: 4, status: 'elaboration', expressionId: 'x' },
  { id: 'b', start: 5, end: 10, status: 'encodable', label: 'Fever', expressionId: 'x' },
  { id: 'c', start: 15, end: 25, status: 'encodable', expressionId: 'x' },
];

describe('encodable text model', () => {
  it('finds the single edit between two strings', () => {
    expect(diffTextEdit('abc', 'abXc')).toEqual({ start: 2, deleteCount: 0, insertText: 'X' });
    expect(diffTextEdit('abcdef', 'abef')).toEqual({ start: 2, deleteCount: 2, insertText: '' });
    expect(diffTextEdit('aaa', 'aaaa')).toEqual({ start: 3, deleteCount: 0, insertText: 'a' });
  });
  it('locks confirmed text', () => {
    const m: EncodableMatch[] = [{ id: 'f', start: 5, end: 10, status: 'confirmed' }];
    expect(editTouchesConfirmed(m, { start: 7, deleteCount: 0, insertText: 'x' })?.id).toBe('f');
    expect(editTouchesConfirmed(m, { start: 4, deleteCount: 2, insertText: '' })?.id).toBe('f');
    expect(editTouchesConfirmed(m, { start: 10, deleteCount: 0, insertText: ' x' })).toBeNull();
    expect(editTouchesConfirmed(m, { start: 5, deleteCount: 0, insertText: 'x ' })).toBeNull();
  });
  it('shifts matches after an edit and drops touched suggestions', () => {
    const out = adjustMatchesForEdit(matches, { start: 0, deleteCount: 0, insertText: 'Very ' });
    expect(out.map(m => [m.id, m.start, m.end])).toEqual([['a', 5, 9], ['b', 10, 15], ['c', 20, 30]]);
    expect(adjustMatchesForEdit(matches, { start: 7, deleteCount: 1, insertText: '' }).map(m => m.id)).toEqual(['a', 'c']);
    expect(adjustMatchesForEdit(matches, { start: 10, deleteCount: 0, insertText: 's' }).map(m => m.id)).toEqual(['a', 'c']);
  });
  it('segments text into one marquee per expression', () => {
    const runs = segmentEncodableText(text + ' and cough', [...matches, { id: 'd', start: 30, end: 35, status: 'encodable' }]);
    expect(runs.map(r => [r.expressionId, r.start, r.end])).toEqual([['x', 0, 25], [null, 25, 30], ['d', 30, 35]]);
    expect(runs[0].segments.map(s => [s.text, s.match?.id ?? null])).toEqual([
      ['mild', 'a'], [' ', null], ['fever', 'b'], [' for ', null], ['three days', 'c'],
    ]);
    expect(segmentEncodableText('', [])).toEqual([{ expressionId: null, start: 0, end: 0, segments: [] }]);
  });
  it('finds the match at the caret and word boundaries', () => {
    expect(matchAtCaret(matches, 7)?.id).toBe('b');
    expect(matchAtCaret(matches, 12)).toBeNull();
    expect(nextWordEnd(text, 10)).toBe(14);
    expect(previousWordEnd(text, 25)).toBe(20);
  });
});
