import React from 'react';
import { cx, formatLongDate, formatLongDateParts, formatShortDate, toDate, useClinicalLocale, MONTH_LONG, VisuallyHidden } from '../../core';
import type { ClinicalRegion, DateLike } from '../../core';
import { DAY_ABBREVIATIONS } from '../utils/regions/dates';
import { DateInputValue, dateInputValueToIso, formatDateInputValue, makeLocalDate } from '../utils/dateInput';

const DAY_LONG = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

export interface DateDisplayProps {
  /**
   * The date: a Date, an ISO string ("2008-04-05" is read as a calendar date), or an entered value
   * including partial dates and unknown. Null, empty or invalid shows `nullText` (D+Ta-0022).
   */
  value: DateLike | DateInputValue | null | undefined;
  /**
   * "short" (default) DD-Mmm-YYYY for all clinical use (D+Ta-0006). "long" DD Month YYYY for
   * communication with patients (D+Ta-0011).
   */
  format?: 'short' | 'long';
  /**
   * Show the day of the week before the date, "Tue 01-Jan-2008" (D+Ta-0016, D+Ta-0017).
   * Do not use for date of birth or date of death. AU uses "Thur" (ACSQHC 2024).
   */
  dayOfWeek?: boolean;
  /** Long format only: ordinal day with superscript lower-case suffix, "1st January 2008" (D+Ta-0019..0021). */
  ordinal?: boolean;
  /** Text for a missing date, e.g. "Unknown" (default) or "Not recorded" (D+Ta-0022). */
  nullText?: string;
  /** Short format only: also give screen readers the long form (D+Ta-0015). Default true. */
  spokenLongForm?: boolean;
  /** Region; otherwise read from ClinicalLocaleProvider. Only the day abbreviation differs (AU "Thur"). */
  region?: ClinicalRegion;
  className?: string;
}

function isEntered(v: unknown): v is DateInputValue {
  return typeof v === 'object' && v !== null && !(v instanceof Date) && 'kind' in v;
}

/**
 * A single date in CUI short or long format, rendered as a `<time>` element. Never shows a numeric
 * month, never follows the user's regional short-date settings (D+Ta-0002, D+Ta-0010).
 */
export function DateDisplay({ value, format = 'short', dayOfWeek, ordinal, nullText = 'Unknown', spokenLongForm = true, region, className }: DateDisplayProps) {
  const dayNames = DAY_ABBREVIATIONS[useClinicalLocale(region).region];
  let date: Date | null = null;
  if (isEntered(value)) {
    if (value.kind === 'monthYear' || value.kind === 'year') {
      const text = format === 'long' && value.kind === 'monthYear' ? `${MONTH_LONG[value.month - 1]} ${value.year}` : formatDateInputValue(value);
      return (
        <time className={cx('cui-date-display', 'cui-date-display--partial', className)} dateTime={dateInputValueToIso(value)}>
          {text}
        </time>
      );
    }
    if (value.kind === 'full') date = makeLocalDate(value.year, value.month, value.day);
  } else {
    date = toDate(value ?? null);
  }
  if (!date) return <span className={cx('cui-date-display', 'cui-date-display--null', className)}>{nullText}</span>;

  const iso = `${String(date.getFullYear()).padStart(4, '0')}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
  const spoken = `${dayOfWeek ? DAY_LONG[date.getDay()] + ' ' : ''}${formatLongDate(date)}`;

  if (format === 'long') {
    const prefix = dayOfWeek ? `${dayNames[date.getDay()]} ` : '';
    if (ordinal) {
      const p = formatLongDateParts(date);
      return (
        <time className={cx('cui-date-display', 'cui-date-display--long', className)} dateTime={iso}>
          {prefix}
          {p?.day}
          <sup className="cui-date-display__ordinal">{p?.suffix}</sup> {p?.rest}
        </time>
      );
    }
    return (
      <time className={cx('cui-date-display', 'cui-date-display--long', className)} dateTime={iso}>
        {`${prefix}${formatLongDate(date)}`}
      </time>
    );
  }

  const short = `${dayOfWeek ? `${dayNames[date.getDay()]} ` : ''}${formatShortDate(date)}`;
  return (
    <time className={cx('cui-date-display', className)} dateTime={iso}>
      {spokenLongForm ? (
        <>
          <span aria-hidden="true">{short}</span>
          <VisuallyHidden>{spoken}</VisuallyHidden>
        </>
      ) : (
        short
      )}
    </time>
  );
}
