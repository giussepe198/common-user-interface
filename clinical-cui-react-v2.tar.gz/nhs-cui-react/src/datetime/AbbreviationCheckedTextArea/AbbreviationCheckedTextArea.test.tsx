import React from 'react';
import { describe, it, expect, vi, afterEach } from 'vitest';
import { render, screen, fireEvent, cleanup } from '@testing-library/react';
import { AbbreviationCheckedTextArea } from './AbbreviationCheckedTextArea';
import { ClinicalLocaleProvider } from '../../core';

afterEach(cleanup);

describe('AbbreviationCheckedTextArea', () => {
  it('alerts on leaving the field and reports invalid while a dangerous item remains (abbracs 3.1)', () => {
    const onValidity = vi.fn();
    render(<AbbreviationCheckedTextArea label="Instructions" defaultValue="Give 10U insulin" onValidityChange={onValidity} />);
    expect(onValidity).toHaveBeenLastCalledWith(false, expect.any(Array));
    expect(screen.queryByRole('alert')).toBeNull();
    fireEvent.blur(screen.getByLabelText('Instructions'));
    expect(screen.getByRole('alert').textContent).toMatch(/1 dangerous item must be resolved/);
  });
  it('offers replacements with none pre-selected and applies the chosen one', () => {
    const onValidity = vi.fn();
    render(<AbbreviationCheckedTextArea label="Instructions" defaultValue="Give 10U insulin" onValidityChange={onValidity} showAlerts />);
    const options = screen.getAllByRole('button').filter(b => ['unit', 'units'].includes(b.textContent ?? ''));
    expect(options.map(b => b.textContent)).toEqual(['unit', 'units']);
    fireEvent.click(options[1]);
    expect((screen.getByLabelText('Instructions') as HTMLTextAreaElement).value).toBe('Give 10units insulin');
    expect(onValidity).toHaveBeenLastCalledWith(true, []);
  });
  it('moves to the next item with F8', () => {
    render(<AbbreviationCheckedTextArea label="Notes" defaultValue="Known AE and ST" />);
    const area = screen.getByLabelText('Notes') as HTMLTextAreaElement;
    area.focus();
    area.setSelectionRange(0, 0);
    fireEvent.keyDown(area, { key: 'F8' });
    expect([area.selectionStart, area.selectionEnd]).toEqual([6, 8]);
    fireEvent.keyDown(area, { key: 'F8' });
    expect([area.selectionStart, area.selectionEnd]).toEqual([13, 15]);
  });
  it('uses the AU list with full-word replacements and the NZ list', () => {
    render(<ClinicalLocaleProvider region="AU"><AbbreviationCheckedTextArea label="Order" defaultValue="500 mcg Q4H" showAlerts /></ClinicalLocaleProvider>);
    expect(screen.getByRole('button', { name: 'microgram' })).toBeTruthy();
    expect(screen.getByRole('button', { name: 'every 4 hours' })).toBeTruthy();
    cleanup();
    render(<AbbreviationCheckedTextArea label="Order" region="NZ" defaultValue="500 mcg q4h" showAlerts />);
    expect(screen.getByRole('alert').textContent).toMatch(/1 dangerous item/);
    expect(screen.getByRole('button', { name: 'microgram' })).toBeTruthy();
  });
  it('warns later readers in read-only mode', () => {
    render(<AbbreviationCheckedTextArea label="Notes" value="Known AE" readOnly />);
    expect(screen.getByRole('note').textContent).toMatch(/1 unexpanded abbreviation \(AE\)/);
  });
});
