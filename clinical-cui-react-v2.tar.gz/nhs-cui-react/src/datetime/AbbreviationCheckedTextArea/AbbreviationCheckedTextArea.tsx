import React, { useEffect, useMemo, useRef, useState } from 'react';
import { cx, useId, useControllableState, useClinicalLocale, Button, Icon } from '../../core';
import type { ClinicalRegion } from '../../core';
import {
  AbbreviationFinding,
  DangerousAbbreviation,
  applyAbbreviationSuggestion,
  getDangerousAbbreviations,
  findDangerousAbbreviations,
  findUnexpandedAbbreviations,
} from '../utils/abbreviations';

export interface AbbreviationCheckedTextAreaProps {
  /** Visible label for the field. */
  label: string;
  value?: string;
  defaultValue?: string;
  onChange?: (value: string) => void;
  /**
   * Known dangerous abbreviations; maintain the list centrally (abbracs 3.1). Default by region:
   * GB the abbracs Appendix A, B and C list; AU the ACSQHC 2024 "do not use" terms; NZ the HQSC
   * "DO NOT USE" list.
   */
  dangerousList?: DangerousAbbreviation[];
  /** Region; otherwise read from ClinicalLocaleProvider. Chooses the default list, suggestions and dose rules. */
  region?: ClinicalRegion;
  /** Other known abbreviations and their possible meanings; flagged as unexpanded but not blocking (abbracsfree). */
  knownAbbreviations?: Record<string, string[]>;
  /** Also check dose formats: trailing zero, missing leading zero, name and dose run together, "/" between doses. Default true. */
  checkDoseFormats?: boolean;
  /**
   * Called when validity changes. `isValid` is false while any dangerous item remains: the host
   * must not store the text (abbracs 3.1: prevent storage under all circumstances).
   */
  onValidityChange?: (isValid: boolean, findings: AbbreviationFinding[]) => void;
  /** Show the alert now, e.g. when the user tries to save. Alerts otherwise appear when the user leaves the field (abbracs 3.1). */
  showAlerts?: boolean;
  rows?: number;
  /** Read-only view for later readers: shows a warning when unexpanded items remain (abbracsfree). */
  readOnly?: boolean;
  disabled?: boolean;
  id?: string;
  className?: string;
}

const KIND_TEXT = (f: AbbreviationFinding) =>
  f.severity === 'unexpanded' ? 'Abbreviation' : f.kind === 'dose-format' ? 'Dose format hazard' : 'Dangerous abbreviation';

/**
 * Free text field that checks for known dangerous abbreviations and dose-format hazards in the
 * background, alerts when the user leaves the field, offers expansions with none pre-selected, and
 * reports `isValid = false` so the host blocks saving while any dangerous item remains (abbracs 3.1;
 * abbracsfree design suggestion).
 */
export const AbbreviationCheckedTextArea = React.forwardRef<HTMLTextAreaElement, AbbreviationCheckedTextAreaProps>(function AbbreviationCheckedTextArea(props, ref) {
  const {
    label, value: valueProp, defaultValue = '', onChange, dangerousList: listProp, knownAbbreviations,
    checkDoseFormats = true, onValidityChange, showAlerts, rows = 4, readOnly, disabled, id, className, region: regionProp,
  } = props;
  const { region } = useClinicalLocale(regionProp);
  const dangerousList = listProp ?? getDangerousAbbreviations(region);
  const fieldId = useId('cui-abbr-text', id);
  const [value, setValue] = useControllableState<string>(valueProp, defaultValue, onChange);
  const [alerted, setAlerted] = useState(false);
  const areaRef = useRef<HTMLTextAreaElement | null>(null);
  const pendingCaret = useRef<number | null>(null);

  const findings = useMemo(() => {
    const dangerous = findDangerousAbbreviations(value, dangerousList, { doseFormats: checkDoseFormats, region });
    const known = knownAbbreviations ? findUnexpandedAbbreviations(value, knownAbbreviations) : [];
    const overlaps = (f: AbbreviationFinding) => dangerous.some(d => f.start < d.end && d.start < f.end);
    return [...dangerous, ...known.filter(f => !overlaps(f))].sort((a, b) => a.start - b.start);
  }, [value, dangerousList, knownAbbreviations, checkDoseFormats, region]);
  const dangerousCount = findings.filter(f => f.severity === 'dangerous').length;
  const isValid = dangerousCount === 0;

  useEffect(() => {
    onValidityChange?.(isValid, findings);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isValid, findings.length]);

  useEffect(() => {
    if (pendingCaret.current != null && areaRef.current) {
      areaRef.current.focus();
      areaRef.current.setSelectionRange(pendingCaret.current, pendingCaret.current);
      pendingCaret.current = null;
    }
  });

  const setRefs = (el: HTMLTextAreaElement | null) => {
    areaRef.current = el;
    if (typeof ref === 'function') ref(el);
    else if (ref) ref.current = el;
  };

  const selectFinding = (f: AbbreviationFinding) => {
    const el = areaRef.current;
    if (!el) return;
    el.focus();
    el.setSelectionRange(f.start, f.end);
  };

  /** "Go to next unexpanded item" (abbracs accessibility), also on F8 [suggested key]. */
  const goToNext = () => {
    const el = areaRef.current;
    if (!el || !findings.length) return;
    const from = el.selectionEnd ?? 0;
    const next = findings.find(f => f.start >= from && !(f.start === el.selectionStart && f.end === el.selectionEnd)) ?? findings[0];
    selectFinding(next);
  };

  const apply = (f: AbbreviationFinding, suggestion: string) => {
    const out = applyAbbreviationSuggestion(value, f, suggestion);
    pendingCaret.current = out.caret;
    setValue(out.text);
  };

  const visible = (alerted || showAlerts) && findings.length > 0 && !readOnly;
  const summaryId = `${fieldId}-summary`;
  const summary =
    dangerousCount > 0
      ? `${dangerousCount} dangerous ${dangerousCount === 1 ? 'item' : 'items'} must be resolved before this text can be saved.`
      : `${findings.length} ${findings.length === 1 ? 'abbreviation is' : 'abbreviations are'} not expanded.`;

  return (
    <div className={cx('cui-abbr-text', className)}>
      <label htmlFor={fieldId} className="cui-abbr-text__label">{label}</label>
      {readOnly && findings.length ? (
        <div className="cui-abbr-text__reader-warning" role="note">
          <Icon name="warning" size={16} />
          <span>
            This text contains {findings.length} unexpanded {findings.length === 1 ? 'abbreviation' : 'abbreviations'} ({findings.map(f => f.text).join(', ')}). Check the meaning before acting on it.
          </span>
        </div>
      ) : null}
      <textarea
        ref={setRefs}
        id={fieldId}
        className={cx('cui-abbr-text__area', visible && dangerousCount > 0 && 'cui-abbr-text__area--invalid')}
        rows={rows}
        value={value}
        readOnly={readOnly}
        disabled={disabled}
        aria-invalid={visible && dangerousCount > 0 ? true : undefined}
        aria-describedby={visible ? summaryId : undefined}
        onChange={e => setValue(e.target.value)}
        onBlur={() => {
          if (findings.length) setAlerted(true);
        }}
        onKeyDown={e => {
          if (e.key === 'F8') {
            e.preventDefault();
            setAlerted(true);
            goToNext();
          }
        }}
      />
      {visible ? (
        <div className={cx('cui-abbr-text__alert', dangerousCount > 0 && 'cui-abbr-text__alert--danger')}>
          <div id={summaryId} role="alert" className="cui-abbr-text__summary">
            <Icon name={dangerousCount > 0 ? 'error' : 'info'} size={16} />
            <span>{summary}</span>
          </div>
          <ul className="cui-abbr-text__list">
            {findings.map((f, i) => (
              <li key={`${f.start}-${i}`} className={cx('cui-abbr-text__item', `cui-abbr-text__item--${f.severity}`)}>
                <div className="cui-abbr-text__item-head">
                  <Icon name={f.severity === 'dangerous' ? 'warning' : 'info'} size={16} />
                  <span className="cui-abbr-text__kind">{KIND_TEXT(f)}</span>
                  <button type="button" className="cui-abbr-text__term" onClick={() => selectFinding(f)} title="Show in text">
                    {f.text.trim() || f.text}
                  </button>
                  <span className="cui-abbr-text__reason">{f.reason}</span>
                </div>
                <div className="cui-abbr-text__options">
                  {f.suggestions.length ? (
                    <>
                      <span className="cui-abbr-text__options-label">{f.resolution === 'expand' ? 'Expand as:' : 'Replace with:'}</span>
                      {f.suggestions.map(s => (
                        <Button key={s} size="sm" onClick={() => apply(f, s)}>
                          {s.trim()}
                        </Button>
                      ))}
                    </>
                  ) : (
                    <span className="cui-abbr-text__options-label">Write this in full.</span>
                  )}
                </div>
              </li>
            ))}
          </ul>
          <div className="cui-abbr-text__footer">
            <Button size="sm" variant="quiet" icon="chevron-right" onClick={goToNext}>
              Go to next item (F8)
            </Button>
          </div>
        </div>
      ) : null}
    </div>
  );
});
