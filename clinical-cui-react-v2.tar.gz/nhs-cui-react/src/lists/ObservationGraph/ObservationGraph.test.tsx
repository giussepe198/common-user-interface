import React from 'react';
import { afterEach, describe, it, expect } from 'vitest';
import { cleanup, render, screen, fireEvent } from '@testing-library/react';
import { ObservationGraph } from './ObservationGraph';
import { ewsGraphZones } from '../utils/earlyWarning';
import { EWS_NZEWS } from '../utils/regions/earlyWarning';

afterEach(cleanup);

const pulse = { id: 'hr', label: 'Pulse rate', unit: 'beats/min', points: [
  { time: '2026-10-27T08:00', value: 82, source: 'machine' as const },
  { time: '2026-10-27T12:00', value: 96, source: 'manual' as const },
] };
const props = { start: '2026-10-27T00:00', end: '2026-10-28T00:00', yRange: { min: 40, max: 160 }, width: 600 };

describe('ObservationGraph', () => {
  it('shows the latest value and keeps the predefined scale (GTAB-045, 072)', () => {
    render(<ObservationGraph {...props} series={[pulse]} normalRange={{ low: 60, high: 100, population: 'adult' }} />);
    expect(screen.getByText(/Latest/).textContent).toMatch(/Latest 96 at 27-Oct-2026 12:00, manual reading/);
    expect(screen.getByText('Normal range (adult) 60 to 100')).toBeTruthy();
    expect(screen.getByText('160')).toBeTruthy();
  });
  it('moves a focus line between readings with the arrow keys and announces values (GTAB-057..065)', () => {
    render(<ObservationGraph {...props} series={[pulse]} />);
    const svg = screen.getByRole('group');
    fireEvent.keyDown(svg, { key: 'ArrowRight' });
    expect(screen.getByText(/27-Oct-2026 12:00: Pulse rate 96 beats\/min, manual/)).toBeTruthy();
    fireEvent.keyDown(svg, { key: 'Home' });
    expect(screen.getByText(/08:00: Pulse rate 82/)).toBeTruthy();
  });
  it('shows a thumbnail beside the graph when values are off the scale (GTAB-078, 082)', () => {
    const off = { ...pulse, points: [...pulse.points, { time: '2026-10-27T14:00', value: 182 }] };
    const { container } = render(<ObservationGraph {...props} series={[off]} />);
    expect(screen.getByText('1 above the scale')).toBeTruthy();
    expect(container.querySelector('.cui-obs-graph__body > .cui-graph-thumb')).toBeTruthy();
    render(<ObservationGraph {...props} series={[pulse]} thumbnail="never" />);
  });
  it('shades early warning zones with named legend entries (GTAB-083)', () => {
    const { container } = render(<ObservationGraph {...props} series={[pulse]} zones={ewsGraphZones(EWS_NZEWS, 'heartRate')} />);
    expect(container.querySelector('.cui-obs-graph__legend')?.textContent).toMatch(/Red zone, score 3/);
    expect(container.querySelectorAll('.cui-obs-graph__zone').length).toBeGreaterThan(3);
  });
  it('offers the table alternative', () => {
    render(<ObservationGraph {...props} series={[pulse]} />);
    fireEvent.click(screen.getByRole('button', { name: 'Show table' }));
    expect(screen.getByRole('table')).toBeTruthy();
  });
});
