import React from 'react';
import { afterEach, describe, it, expect, vi } from 'vitest';
import { cleanup, render, screen, fireEvent } from '@testing-library/react';
import { FilterNotification } from './FilterNotification';
import type { ListAttribute } from '../utils/listTypes';

afterEach(cleanup);

const attrs: ListAttribute[] = [{ id: 'news', label: 'NEWS2 score', dataType: 'integer' }];
const filter = { combine: 'or' as const, criteria: [{ attributeId: 'news', operator: 'greaterThanOrEqual' as const, value: '5' }] };

describe('FilterNotification', () => {
  it('starts "Data filtered to show" and removes all filters (FSG-0073, FSG-0057)', () => {
    const onRemoveAll = vi.fn();
    render(<FilterNotification filter={filter} attributes={attrs} onRemoveAll={onRemoveAll} counts={{ in: 2, out: 3, all: 5 }} rowNoun="patients" />);
    expect(screen.getByRole('status').textContent).toMatch(/^Data filtered to show/);
    expect(screen.getByText(/2 of 5 patients shown/)).toBeTruthy();
    fireEvent.click(screen.getByRole('button', { name: 'Remove all filters' }));
    expect(onRemoveAll).toHaveBeenCalled();
  });
  it('moves between result tabs with the arrow keys (FSG-0068)', () => {
    const onViewChange = vi.fn();
    render(<FilterNotification filter={filter} attributes={attrs} onRemoveAll={() => {}} counts={{ in: 2, out: 3, all: 5 }} view="in" onViewChange={onViewChange} />);
    const tabs = screen.getAllByRole('tab');
    expect(tabs[0].getAttribute('aria-selected')).toBe('true');
    fireEvent.keyDown(tabs[0], { key: 'ArrowRight' });
    expect(onViewChange).toHaveBeenCalledWith('out');
    fireEvent.keyDown(tabs[0], { key: 'ArrowLeft' });
    expect(onViewChange).toHaveBeenLastCalledWith('all');
  });
});
