import React from 'react';
import { afterEach, describe, it, expect } from 'vitest';
import { cleanup, render, screen, fireEvent } from '@testing-library/react';
import { ObservationTable } from './ObservationTable';
import { ewsObservationAnnotator } from '../utils/earlyWarning';
import { EWS_NZEWS } from '../utils/regions/earlyWarning';

afterEach(cleanup);

const series = [
  { id: 'temperature', label: 'Temperature', unit: '°C', points: [
    { time: '2026-10-27T08:00', value: 37, display: '37.0', source: 'machine' as const },
    { time: '2026-10-27T12:00', value: 38.25, source: 'manual' as const },
  ], roundTo: 1 },
];

describe('ObservationTable', () => {
  it('puts the newest at the top and keeps recorded precision, flagging rounding (GTAB-188, 194..196)', () => {
    render(<ObservationTable series={series} caption="Vital signs" />);
    const rows = screen.getAllByRole('row');
    expect(rows[1].textContent).toMatch(/12:00/);
    expect(screen.getByText(/rounded; recorded 38.25/)).toBeTruthy();
    expect(screen.getByText(/Some values are rounded/)).toBeTruthy();
    expect(screen.getByText('manual')).toBeTruthy();
  });
  it('swaps rows and columns and reverses the order', () => {
    render(<ObservationTable series={series} />);
    fireEvent.click(screen.getByRole('button', { name: 'Swap rows and columns' }));
    expect(screen.getAllByRole('row')[0].textContent).toMatch(/^Date/);
    fireEvent.click(screen.getByRole('button', { name: 'Show newest on left' }));
    expect(screen.getByRole('button', { name: 'Show newest on right' })).toBeTruthy();
  });
  it('annotates values with early warning score and zone in words (GTAB-083)', () => {
    const { container } = render(<ObservationTable series={series} annotate={ewsObservationAnnotator(EWS_NZEWS)} />);
    expect(screen.getByText(', score 1, yellow zone')).toBeTruthy();
    const cell = container.querySelector('td[style]') as HTMLElement;
    expect(cell.style.background).toContain('--ews-zone-yellow');
  });
});
