import React from 'react';
import { describe, it, expect, vi, afterEach } from 'vitest';
import { render, screen, fireEvent, cleanup } from '@testing-library/react';
import { MedicareNumberInput } from './MedicareNumberInput';

afterEach(cleanup);

describe('MedicareNumberInput', () => {
  it('groups 4-5-1 and takes the IRN in its own box', () => {
    const onChange = vi.fn();
    const onIrn = vi.fn();
    render(<MedicareNumberInput onChange={onChange} onIrnChange={onIrn} />);
    const box = screen.getByLabelText('Medicare card number') as HTMLInputElement;
    fireEvent.change(box, { target: { value: '2123456701' } });
    expect(box.value).toBe('2123 45670 1');
    expect(onChange).toHaveBeenLastCalledWith('2123 45670 1', '2123456701');
    fireEvent.change(screen.getByLabelText('IRN'), { target: { value: 'x1' } });
    expect(onIrn).toHaveBeenLastCalledWith('1');
  });
  it('check digit and issue number errors on blur', () => {
    render(<MedicareNumberInput defaultValue="2123456711" />);
    fireEvent.blur(screen.getByLabelText('Medicare card number'));
    expect(screen.getByRole('alert').textContent).toMatch(/not a valid Medicare/);
  });
  it('IRN required once a number is entered (AU-ID-03); validity needs both', () => {
    const validity = vi.fn();
    render(<MedicareNumberInput defaultValue="2123456701" onValidityChange={validity} />);
    expect(validity).toHaveBeenLastCalledWith(false);
    const irn = screen.getByLabelText('IRN');
    fireEvent.blur(irn);
    expect(screen.getByRole('alert').textContent).toMatch(/Enter the IRN/);
    fireEvent.change(irn, { target: { value: '2' } });
    expect(validity).toHaveBeenLastCalledWith(true);
  });
  it('is a labelled group', () => {
    render(<MedicareNumberInput />);
    expect(screen.getByRole('group', { name: 'Medicare card number and IRN' })).toBeTruthy();
  });
});
