import React from 'react';
import { describe, it, expect, afterEach } from 'vitest';
import { render, cleanup } from '@testing-library/react';
import { PatientNameDisplay } from './PatientNameDisplay';
import { ClinicalLocaleProvider } from '../../core';

afterEach(cleanup);

describe('PatientNameDisplay', () => {
  it('GB: FAMILY, Given (Title) with unknown text for a missing given name (NID-0004, PAB-0019)', () => {
    const { container, rerender } = render(<PatientNameDisplay familyName="lidman - sun-dewar" givenName="anne-jorun" title="mrs." />);
    expect(container.textContent).toBe('LIDMAN-SUN-DEWAR, Anne-Jorun (Mrs)');
    rerender(<PatientNameDisplay familyName="Smith" givenName="" />);
    expect(container.textContent).toBe('SMITH, Not Known');
  });
  it('keeps each component on one line (NID-0013)', () => {
    const { container } = render(<PatientNameDisplay familyName="Evans West" givenName="Anne" />);
    expect(container.querySelectorAll('.cui-patient-name__part')).toHaveLength(3);
  });
  it('AU: no title by default, single name alone (AU-PI-02, AU-NM-01)', () => {
    const { container } = render(<PatientNameDisplay region="AU" familyName="Ngapanji" givenName="" title="Mr" />);
    expect(container.textContent).toBe('NGAPANJI');
  });
  it('NZ: family name as recorded, macrons preserved, distinguished by weight (G11 2.3)', () => {
    const { container } = render(
      <ClinicalLocaleProvider region="NZ">
        <PatientNameDisplay familyName="Ngāwai" givenName="Kāhu" />
      </ClinicalLocaleProvider>,
    );
    expect(container.textContent).toBe('Ngāwai, Kāhu');
    expect(container.querySelector('.cui-patient-name--as-recorded')).toBeTruthy();
  });
  it('NZ upper-case option keeps macrons', () => {
    const { container } = render(<PatientNameDisplay region="NZ" familyNameCase="upper" familyName="Ngāwai" givenName="Kāhu" />);
    expect(container.textContent).toBe('NGĀWAI, Kāhu');
  });
  it('unidentified qualifier (AU-NM-02)', () => {
    const { container } = render(<PatientNameDisplay region="AU" familyName="Unknown" givenName="Male 3" unidentified />);
    expect(container.textContent).toBe('UNKNOWN, Male 3 Unidentified patient');
  });
});
