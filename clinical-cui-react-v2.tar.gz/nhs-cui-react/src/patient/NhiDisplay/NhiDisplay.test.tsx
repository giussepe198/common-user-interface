import React from 'react';
import { describe, it, expect, afterEach } from 'vitest';
import { render, cleanup } from '@testing-library/react';
import { NhiDisplay } from './NhiDisplay';

afterEach(cleanup);

describe('NhiDisplay', () => {
  it('7 characters, upper case, ungrouped (G11 1.3)', () => {
    const { container } = render(<NhiDisplay label="NHI" value="aca31fm" />);
    expect(container.textContent).toBe('NHI ACA31FM');
  });
  it('flags test-range and invalid numbers in text', () => {
    const { container, rerender } = render(<NhiDisplay value="ZAC5361" />);
    expect(container.textContent).toBe('ZAC5361 Test NHI');
    rerender(<NhiDisplay value="ZAC5362" />);
    expect(container.textContent).toBe('ZAC5362 not a valid NHI');
    rerender(<NhiDisplay value="ZAC5361" flagTestNumbers={false} />);
    expect(container.textContent).toBe('ZAC5361');
  });
  it('can show the format', () => {
    const { container } = render(<NhiDisplay value="ACA31FM" showFormat />);
    expect(container.textContent).toBe('ACA31FM (new format)');
  });
});
