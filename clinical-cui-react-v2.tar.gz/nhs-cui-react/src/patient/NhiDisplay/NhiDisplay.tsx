import React from 'react';
import { formatNhi, isTestNhi, isValidNhi, nhiFormat } from '../utils/identifiers';
import { IdentifierDisplayBase } from '../PatientIdentifierDisplay/IdentifierDisplayBase';
import type { IdentifierFlag } from '../PatientIdentifierDisplay/IdentifierDisplayBase';

export interface NhiDisplayProps {
  /** National Health Index number, either format. Shown as 7 upper-case characters, never grouped (G11 1.3). */
  value: string | null | undefined;
  /** Optional label; the patient banner uses "NHI" (G11 1.3). */
  label?: string;
  /** Definition for the label tooltip (PAB-0047). */
  definition?: string;
  /** Text when no NHI is held. Default "Not Known". */
  unknownText?: string;
  /** Flag a value that fails the format or check character test (mod 11 legacy, mod 23 new). Shown as supplied. Default true. */
  flagInvalid?: boolean;
  /** Flag Z-range test NHIs with "Test NHI" (HISO 10046). Turn off in test environments. Default true. */
  flagTestNumbers?: boolean;
  /** Show the format, "(legacy format)" or "(new format)", so users can tell them apart (G11 1.1) [suggested]. Default false. */
  showFormat?: boolean;
  /** Makes the number a button that opens the record (PAB-0048). */
  onOpenRecord?: () => void;
  className?: string;
}

/** NHI number display: 7 characters, upper case, no spaces; invalid and test-range numbers flagged in text (G11 1.1-1.3). */
export function NhiDisplay({
  value,
  label,
  definition,
  unknownText,
  flagInvalid = true,
  flagTestNumbers = true,
  showFormat = false,
  onOpenRecord,
  className,
}: NhiDisplayProps) {
  const raw = (value ?? '').trim();
  const valid = isValidNhi(raw);
  const formatted = valid ? formatNhi(raw) : null;
  const flags: IdentifierFlag[] = [];
  if (raw && flagInvalid && !valid) flags.push({ text: 'not a valid NHI', tone: 'warning' });
  if (raw && flagTestNumbers && valid && isTestNhi(raw)) flags.push({ text: 'Test NHI', tone: 'warning' });
  if (raw && valid && showFormat) flags.push({ text: nhiFormat(raw) === 'new' ? 'new format' : 'legacy format', tone: 'info' });
  return (
    <IdentifierDisplayBase
      kind="nhi"
      raw={raw}
      formatted={formatted}
      flags={flags}
      label={label}
      definition={definition}
      unknownText={unknownText}
      onOpenRecord={onOpenRecord}
      className={className}
    />
  );
}
