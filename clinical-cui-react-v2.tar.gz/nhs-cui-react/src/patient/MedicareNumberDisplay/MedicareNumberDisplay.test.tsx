import React from 'react';
import { describe, it, expect, afterEach } from 'vitest';
import { render, cleanup } from '@testing-library/react';
import { MedicareNumberDisplay } from './MedicareNumberDisplay';

afterEach(cleanup);

describe('MedicareNumberDisplay', () => {
  it('shows the number as on the card with the IRN (AU-ID-03)', () => {
    const { container } = render(<MedicareNumberDisplay label="Medicare" value="2123456701" irn="1" />);
    expect(container.textContent).toBe('Medicare 2123 45670 1 IRN 1');
  });
  it('reads an 11th digit as the IRN', () => {
    const { container } = render(<MedicareNumberDisplay value="21234567012" />);
    expect(container.textContent).toBe('2123 45670 1 IRN 2');
  });
  it('flags a missing IRN and an invalid number in text', () => {
    const { container, rerender } = render(<MedicareNumberDisplay value="2123456701" />);
    expect(container.textContent).toContain('IRN not recorded');
    rerender(<MedicareNumberDisplay value="2123456711" irn="1" />);
    expect(container.textContent).toContain('not a valid Medicare number');
  });
});
