import React from 'react';
import { formatMedicareNumber, isValidMedicareIrn, isValidMedicareNumber } from '../utils/identifiers';
import { IdentifierDisplayBase } from '../PatientIdentifierDisplay/IdentifierDisplayBase';
import type { IdentifierFlag } from '../PatientIdentifierDisplay/IdentifierDisplayBase';

export interface MedicareNumberDisplayProps {
  /** Medicare card number, 10 digits (identifier, check digit, issue number). An 11th digit is read as the IRN. Shown "2123 45670 1" (G10 1.3, [UNCERTAIN] card grouping). */
  value: string | null | undefined;
  /** Individual Reference Number, 1-9: the number to the left of the person's name on the card. Always shown with the number (AU-ID-03). */
  irn?: string | null;
  /** Optional label; the patient banner uses "Medicare". */
  label?: string;
  /** Definition for the label tooltip (PAB-0047). */
  definition?: string;
  /** Text when no number is held. Default "Not Known". */
  unknownText?: string;
  /** Flag a number that fails the structure or check digit test. Default true. */
  flagInvalid?: boolean;
  /** Makes the number a button that opens the record (PAB-0048). */
  onOpenRecord?: () => void;
  className?: string;
}

/**
 * Medicare card number as printed on the card with the IRN alongside, "2123 45670 1 IRN 1" (G10 1.3).
 * A Medicare number is shared by a family, so a missing IRN is flagged in text (AU-ID-03).
 */
export function MedicareNumberDisplay({
  value,
  irn,
  label,
  definition,
  unknownText,
  flagInvalid = true,
  onOpenRecord,
  className,
}: MedicareNumberDisplayProps) {
  const raw = (value ?? '').trim();
  const digits = raw.replace(/\s+/g, '');
  const irnValue = (irn ?? '').trim() || (digits.length === 11 ? digits[10] : '');
  const valid = isValidMedicareNumber(digits);
  const formatted = valid ? formatMedicareNumber(digits) : null;
  const flags: IdentifierFlag[] = [];
  if (raw && flagInvalid && !valid) flags.push({ text: 'not a valid Medicare number', tone: 'warning' });
  if (raw && !irnValue) flags.push({ text: 'IRN not recorded', tone: 'warning' });
  else if (raw && irnValue && !isValidMedicareIrn(irnValue)) flags.push({ text: 'IRN not valid', tone: 'warning' });
  return (
    <IdentifierDisplayBase
      kind="medicare"
      raw={raw}
      formatted={formatted}
      suffix={raw && irnValue ? `IRN ${irnValue}` : undefined}
      flags={flags}
      label={label}
      definition={definition}
      unknownText={unknownText}
      onOpenRecord={onOpenRecord}
      className={className}
    />
  );
}
