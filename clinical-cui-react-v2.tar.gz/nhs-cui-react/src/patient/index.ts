import './LabelledValue/LabelledValue.css';
import './PatientNameDisplay/PatientNameDisplay.css';
import './NhsNumberDisplay/NhsNumberDisplay.css';
import './NhsNumberInput/NhsNumberInput.css';
import './GenderDisplay/GenderDisplay.css';
import './SexGenderInput/SexGenderInput.css';
import './AddressDisplay/AddressDisplay.css';
import './AddressInput/AddressInput.css';
import './TelephoneNumberDisplay/TelephoneNumberDisplay.css';
import './TelephoneNumberInput/TelephoneNumberInput.css';
import './PatientNameInput/PatientNameInput.css';
import './PatientBanner/PatientBanner.css';
import './MicroPatientBanner/MicroPatientBanner.css';
import './PatientIdentifierInput/PatientIdentifierInput.css';
import './PatientIdentifierDisplay/PatientIdentifierDisplay.css';
import './MedicareNumberInput/MedicareNumberInput.css';
import './IndigenousStatusInput/IndigenousStatusInput.css';
import './EthnicityInput/EthnicityInput.css';
import './EthnicityDisplay/EthnicityDisplay.css';
import './MaoriDescentInput/MaoriDescentInput.css';
import './IwiInput/IwiInput.css';

export { PatientBanner } from './PatientBanner/PatientBanner';
export type {
  PatientBannerProps,
  PatientBannerName,
  PatientBannerAddress,
  PatientBannerContacts,
  PatientBannerAllergy,
  PatientBannerAllergies,
  PatientBannerSection,
  PatientRecordItem,
} from './PatientBanner/PatientBanner';
export { MicroPatientBanner } from './MicroPatientBanner/MicroPatientBanner';
export type { MicroPatientBannerProps } from './MicroPatientBanner/MicroPatientBanner';
export { LabelledValue } from './LabelledValue/LabelledValue';
export type { LabelledValueProps } from './LabelledValue/LabelledValue';
export { PatientNameDisplay } from './PatientNameDisplay/PatientNameDisplay';
export type { PatientNameDisplayProps } from './PatientNameDisplay/PatientNameDisplay';
export { PatientNameInput } from './PatientNameInput/PatientNameInput';
export type { PatientNameInputProps, PatientNameValue } from './PatientNameInput/PatientNameInput';
export { NhsNumberDisplay } from './NhsNumberDisplay/NhsNumberDisplay';
export type { NhsNumberDisplayProps } from './NhsNumberDisplay/NhsNumberDisplay';
export { NhsNumberInput } from './NhsNumberInput/NhsNumberInput';
export type { NhsNumberInputProps } from './NhsNumberInput/NhsNumberInput';
export { GenderDisplay } from './GenderDisplay/GenderDisplay';
export type { GenderDisplayProps } from './GenderDisplay/GenderDisplay';
export { SexGenderInput } from './SexGenderInput/SexGenderInput';
export type { SexGenderInputProps, SexGenderInputBaseProps } from './SexGenderInput/SexGenderInput';
export { REGIONAL_SEX_GENDER, findSexGenderValue } from './GenderDisplay/GenderDisplay';
export { AddressDisplay } from './AddressDisplay/AddressDisplay';
export type { AddressDisplayProps } from './AddressDisplay/AddressDisplay';
export { AddressInput, addressInputToValue } from './AddressInput/AddressInput';
export type { AddressInputProps, AddressInputValue, AddressLookupResult, AddressFinderQuery } from './AddressInput/AddressInput';
export { TelephoneNumberDisplay } from './TelephoneNumberDisplay/TelephoneNumberDisplay';
export type { TelephoneNumberDisplayProps } from './TelephoneNumberDisplay/TelephoneNumberDisplay';
export { TelephoneNumberInput } from './TelephoneNumberInput/TelephoneNumberInput';
export type { TelephoneNumberInputProps } from './TelephoneNumberInput/TelephoneNumberInput';
export { IhiInput } from './IhiInput/IhiInput';
export type { IhiInputProps } from './IhiInput/IhiInput';
export { IhiDisplay, ihiStatusQualifiers } from './IhiDisplay/IhiDisplay';
export type { IhiDisplayProps } from './IhiDisplay/IhiDisplay';
export { MedicareNumberInput } from './MedicareNumberInput/MedicareNumberInput';
export type { MedicareNumberInputProps } from './MedicareNumberInput/MedicareNumberInput';
export { MedicareNumberDisplay } from './MedicareNumberDisplay/MedicareNumberDisplay';
export type { MedicareNumberDisplayProps } from './MedicareNumberDisplay/MedicareNumberDisplay';
export { DvaNumberInput } from './DvaNumberInput/DvaNumberInput';
export type { DvaNumberInputProps } from './DvaNumberInput/DvaNumberInput';
export { NhiInput } from './NhiInput/NhiInput';
export type { NhiInputProps } from './NhiInput/NhiInput';
export { NhiDisplay } from './NhiDisplay/NhiDisplay';
export type { NhiDisplayProps } from './NhiDisplay/NhiDisplay';
export { HpiNumberDisplay, HPI_IDENTIFIER_LABELS } from './HpiNumberDisplay/HpiNumberDisplay';
export type { HpiNumberDisplayProps, HpiIdentifierType } from './HpiNumberDisplay/HpiNumberDisplay';
export { PatientIdentifierInput } from './PatientIdentifierInput/PatientIdentifierInput';
export type { PatientIdentifierInputProps } from './PatientIdentifierInput/PatientIdentifierInput';
export { PatientIdentifierDisplay, MRN_LABELS, patientIdentifierLabel } from './PatientIdentifierDisplay/PatientIdentifierDisplay';
export type { PatientIdentifierDisplayProps, PatientIdentifier } from './PatientIdentifierDisplay/PatientIdentifierDisplay';
export { IndigenousStatusInput, indigenousStatusFromBoxes } from './IndigenousStatusInput/IndigenousStatusInput';
export type { IndigenousStatusInputProps } from './IndigenousStatusInput/IndigenousStatusInput';
export { IndigenousStatusDisplay } from './IndigenousStatusDisplay/IndigenousStatusDisplay';
export type { IndigenousStatusDisplayProps } from './IndigenousStatusDisplay/IndigenousStatusDisplay';
export { EthnicityInput, ethnicityCodes, ethnicityNeedsReduction } from './EthnicityInput/EthnicityInput';
export type { EthnicityInputProps, EthnicityValue, EthnicityEntry, EthnicityClassificationItem } from './EthnicityInput/EthnicityInput';
export { EthnicityDisplay, ethnicityDisplayTexts } from './EthnicityDisplay/EthnicityDisplay';
export type { EthnicityDisplayProps } from './EthnicityDisplay/EthnicityDisplay';
export { MaoriDescentInput } from './MaoriDescentInput/MaoriDescentInput';
export type { MaoriDescentInputProps } from './MaoriDescentInput/MaoriDescentInput';
export { IwiInput, filterIwiOptions } from './IwiInput/IwiInput';
export type { IwiInputProps, IwiValue, IwiEntry, IwiOption } from './IwiInput/IwiInput';
export * from './utils/patient';
export * from './utils/countries';
export * from './utils/identifiers';
export * from './utils/regions/identifiers';
export * from './utils/regions/demographics';
export * from './utils/regions/address';
export * from './utils/regions/banner';
