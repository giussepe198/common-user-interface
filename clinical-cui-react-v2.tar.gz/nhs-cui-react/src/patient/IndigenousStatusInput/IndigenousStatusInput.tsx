import React from 'react';
import { cx, Icon, useControllableState, useId } from '../../core';
import { AU_INDIGENOUS_STATUS_QUESTION, AU_INDIGENOUS_STATUS_VALUES } from '../utils/regions/demographics';
import type { IndigenousStatusCode } from '../utils/regions/demographics';

export interface IndigenousStatusInputProps {
  /** Controlled METeOR 602543 code: 1 Aboriginal, 2 Torres Strait Islander, 3 both, 4 neither, 9 not stated; null when unanswered. */
  value?: IndigenousStatusCode | null;
  /** Uncontrolled initial value. Default null: nothing selected (AU-IS-02). */
  defaultValue?: IndigenousStatusCode | null;
  /** Called with the derived code, or null when every box is cleared. */
  onChange?: (code: IndigenousStatusCode | null) => void;
  /** Legend. Default the standard question "Are you of Aboriginal or Torres Strait Islander origin?" (METeOR 602543). */
  question?: string;
  /** Show the instruction for marking both "Yes" boxes. Default true. */
  showBothInstruction?: boolean;
  /** Show the derived code read-only below the boxes (AU-IS-01). Default true. */
  showDerivedCode?: boolean;
  /**
   * Offer a separate "not answered" choice, recorded as code 9, for when the person declined or could not communicate
   * and no one who knows them was available (METeOR collection guidance). Kept apart from the standard tick boxes. Default true.
   */
  allowNotStated?: boolean;
  /** Why the question is asked, shown below the question [suggested]. */
  purpose?: string;
  /** Error from the consumer. */
  error?: string;
  disabled?: boolean;
  id?: string;
  className?: string;
}

type Boxes = { no: boolean; aboriginal: boolean; tsi: boolean; notStated: boolean };

/** Tick boxes to METeOR code: both "Yes" boxes give 3 (AU-IS-01). */
export function indigenousStatusFromBoxes(b: { no?: boolean; aboriginal?: boolean; tsi?: boolean; notStated?: boolean }): IndigenousStatusCode | null {
  if (b.notStated) return '9';
  if (b.aboriginal && b.tsi) return '3';
  if (b.aboriginal) return '1';
  if (b.tsi) return '2';
  if (b.no) return '4';
  return null;
}

function boxesFromCode(code: IndigenousStatusCode | null | undefined): Boxes {
  return {
    no: code === '4',
    aboriginal: code === '1' || code === '3',
    tsi: code === '2' || code === '3',
    notStated: code === '9',
  };
}

/**
 * Australian Indigenous status question as a checkbox group so "both" can be recorded (METeOR 602543, AU-IS-01, AU-IS-02).
 * "No" and the "Yes" boxes exclude each other. Never guess or pre-fill: ask every person.
 */
export function IndigenousStatusInput({
  value,
  defaultValue = null,
  onChange,
  question = AU_INDIGENOUS_STATUS_QUESTION.question,
  showBothInstruction = true,
  showDerivedCode = true,
  allowNotStated = true,
  purpose,
  error,
  disabled,
  id: idProp,
  className,
}: IndigenousStatusInputProps) {
  const id = useId('cui-indigenous', idProp);
  const [code, setCode] = useControllableState<IndigenousStatusCode | null>(value, defaultValue, onChange);
  const boxes = boxesFromCode(code);
  const toggle = (key: keyof Boxes, checked: boolean) => {
    let next: Boxes = { ...boxes, [key]: checked };
    if (checked && key === 'no') next = { no: true, aboriginal: false, tsi: false, notStated: false };
    if (checked && (key === 'aboriginal' || key === 'tsi')) next = { ...next, no: false, notStated: false };
    if (checked && key === 'notStated') next = { no: false, aboriginal: false, tsi: false, notStated: true };
    setCode(indigenousStatusFromBoxes(next));
  };
  const derived = AU_INDIGENOUS_STATUS_VALUES.find((v) => v.code === code);
  const hintId = `${id}-hint`;
  const errId = `${id}-error`;
  return (
    <fieldset
      className={cx('cui-patient-question', 'cui-indigenous-input', error && 'cui-patient-question--error', className)}
      disabled={disabled}
      aria-describedby={cx(showBothInstruction && hintId, error && errId) || undefined}
    >
      <legend className="cui-patient-question__legend">{question}</legend>
      {purpose ? <p className="cui-patient-question__purpose">{purpose}</p> : null}
      {showBothInstruction ? (
        <p id={hintId} className="cui-patient-question__hint">
          {AU_INDIGENOUS_STATUS_QUESTION.bothInstruction}
        </p>
      ) : null}
      <div className="cui-patient-question__options">
        {AU_INDIGENOUS_STATUS_QUESTION.options.map((o) => (
          <div key={o.key} className="cui-patient-question__option">
            <input
              type="checkbox"
              id={`${id}-${o.key}`}
              checked={boxes[o.key]}
              onChange={(e) => toggle(o.key, e.target.checked)}
            />
            <label htmlFor={`${id}-${o.key}`}>{o.label}</label>
          </div>
        ))}
      </div>
      {allowNotStated ? (
        <div className="cui-patient-question__option cui-patient-question__option--separate">
          <input type="checkbox" id={`${id}-not-stated`} checked={boxes.notStated} onChange={(e) => toggle('notStated', e.target.checked)} />
          <label htmlFor={`${id}-not-stated`}>Not answered: the person declined or could not be asked</label>
        </div>
      ) : null}
      {showDerivedCode ? (
        <output className="cui-patient-question__derived" htmlFor={`${id}-no ${id}-aboriginal ${id}-tsi`} aria-live="polite">
          {derived ? `Recorded as: ${derived.label} (code ${derived.code})` : 'Not yet answered'}
        </output>
      ) : null}
      {error ? (
        <div id={errId} className="cui-patient-question__error" role="alert">
          <Icon name="error" size={16} />
          <span>{error}</span>
        </div>
      ) : null}
    </fieldset>
  );
}
