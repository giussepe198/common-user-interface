import React from 'react';
import { describe, it, expect, vi, afterEach } from 'vitest';
import { render, screen, fireEvent, cleanup } from '@testing-library/react';
import { NhiInput } from './NhiInput';

afterEach(cleanup);

describe('NhiInput', () => {
  it('accepts lower case and normalises to upper case on blur (G11 1.3)', () => {
    const onChange = vi.fn();
    render(<NhiInput onChange={onChange} flagTestNumbers={false} />);
    const box = screen.getByLabelText('NHI number') as HTMLInputElement;
    fireEvent.change(box, { target: { value: 'zbn77vl' } });
    expect(onChange).toHaveBeenLastCalledWith('zbn77vl', 'ZBN77VL');
    fireEvent.blur(box);
    expect(box.value).toBe('ZBN77VL');
    expect(screen.queryByRole('alert')).toBeNull();
  });
  it('both formats valid; a bad check character is an error', () => {
    const validity = vi.fn();
    render(<NhiInput defaultValue="ZAC5361" onValidityChange={validity} flagTestNumbers={false} />);
    expect(validity).toHaveBeenLastCalledWith(true);
    const box = screen.getByLabelText('NHI number');
    fireEvent.change(box, { target: { value: 'ZAC5362' } });
    fireEvent.blur(box);
    expect(screen.getByRole('alert').textContent).toBe('Check the NHI number. It is not a valid NHI');
  });
  it('I and O get their own message', () => {
    render(<NhiInput defaultValue="ZAI5361" />);
    fireEvent.blur(screen.getByLabelText('NHI number'));
    expect(screen.getByRole('alert').textContent).toBe('NHI numbers do not use the letters I or O');
  });
  it('warns for the Z test range', () => {
    render(<NhiInput defaultValue="ZBN77VL" />);
    fireEvent.blur(screen.getByLabelText('NHI number'));
    expect(screen.getByText('This is a test NHI number')).toBeTruthy();
  });
  it('never more than 7 characters, no grouping', () => {
    render(<NhiInput />);
    const box = screen.getByLabelText('NHI number') as HTMLInputElement;
    fireEvent.change(box, { target: { value: 'ACA 31FM99' } });
    expect(box.value).toBe('ACA31FM');
  });
});
