import React from 'react';
import { isTestNhi, nhiError, nhiFormat, normaliseNhi, TEST_NHI_WARNING } from '../utils/identifiers';
import { IdentifierTextInput } from '../PatientIdentifierInput/IdentifierTextInput';

export interface NhiInputProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'value' | 'defaultValue' | 'onChange' | 'size' | 'maxLength' | 'type'> {
  /** Visible label. Default "NHI number" (forms; banners use "NHI", G11 1.3). */
  label?: string;
  /** Hint. Default "7 characters, e.g. ZAC5361 or ZBN77VL". Pass "" for none. */
  hint?: string;
  /** Tooltip on the box. */
  tooltip?: string;
  /** Controlled value. Lower case and spaces are accepted and normalised to upper case when the field is left (G11 1.3). */
  value?: string;
  /** Uncontrolled initial value. */
  defaultValue?: string;
  /** Called with the text as shown and the normalised NHI (upper case, no spaces). */
  onChange?: (shown: string, nhi: string) => void;
  /** Empty is an error once the field is left. Default false. */
  required?: boolean;
  /** Warn "This is a test NHI number" for the Z range (HISO 10046). Turn off in test environments. Default true. */
  flagTestNumbers?: boolean;
  /** Error from the consumer, for example after an NHI search. Overrides built-in validation. */
  error?: string;
  /** Called when validity changes: either format with a correct check character. */
  onValidityChange?: (valid: boolean) => void;
}

/**
 * National Health Index number input (G11 1.1-1.3). Accepts both formats, legacy AAANNNC (mod 11) and new AAANNAX
 * (mod 23), 7 characters, never grouped. I and O get their own message because users often type them for 1 and 0.
 */
export const NhiInput = React.forwardRef<HTMLInputElement, NhiInputProps>(function NhiInput(
  {
    label = 'NHI number',
    hint = '7 characters, e.g. ZAC5361 or ZBN77VL',
    tooltip = 'Enter the National Health Index (NHI) number',
    onChange,
    required = false,
    flagTestNumbers = true,
    ...rest
  },
  ref,
) {
  return (
    <IdentifierTextInput
      {...rest}
      ref={ref}
      blockClass="cui-nhi-input"
      label={label}
      hint={hint || undefined}
      tooltip={tooltip}
      required={required}
      widthCh={8}
      sanitise={(raw) => {
        const kept = raw.replace(/[^A-Za-z0-9]/g, '');
        const shown = kept.slice(0, 7);
        return {
          display: shown,
          normalised: normaliseNhi(shown),
          note: /[^A-Za-z0-9\s]/.test(raw) ? 'Only letters and numbers can be entered in an NHI number.' : kept.length > 7 ? 'An NHI number has 7 characters.' : undefined,
        };
      }}
      normaliseOnBlur={(shown) => normaliseNhi(shown)}
      validate={(nhi) => nhiError(nhi, { required })}
      warn={(nhi) => (flagTestNumbers && nhiFormat(nhi) && isTestNhi(nhi) ? TEST_NHI_WARNING : null)}
      isComplete={(nhi) => nhi.length === 7}
      onChange={onChange}
    />
  );
});
