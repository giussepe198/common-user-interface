import React from 'react';
import { describe, it, expect, vi, afterEach } from 'vitest';
import { render, screen, fireEvent, cleanup } from '@testing-library/react';
import { PatientIdentifierInput } from './PatientIdentifierInput';
import { ClinicalLocaleProvider } from '../../core';

afterEach(cleanup);

describe('PatientIdentifierInput', () => {
  it('defaults to the region primary identifier', () => {
    const { rerender } = render(<PatientIdentifierInput />);
    expect(screen.getByLabelText('NHS Number')).toBeTruthy();
    rerender(<PatientIdentifierInput region="AU" />);
    expect(screen.getByLabelText('IHI')).toBeTruthy();
    rerender(
      <ClinicalLocaleProvider region="NZ">
        <PatientIdentifierInput />
      </ClinicalLocaleProvider>,
    );
    expect(screen.getByLabelText('NHI number')).toBeTruthy();
  });
  it('picks Medicare with IRN and DVA by type', () => {
    const { rerender } = render(<PatientIdentifierInput region="AU" type="medicare" />);
    expect(screen.getByLabelText('IRN')).toBeTruthy();
    rerender(<PatientIdentifierInput region="AU" type="dva" />);
    expect(screen.getByLabelText('DVA file number')).toBeTruthy();
  });
  it('MRN: AU label URN with a local pattern (AU-ID-04)', () => {
    const onChange = vi.fn();
    render(<PatientIdentifierInput region="AU" type="mrn" mrnPattern={/^\d{7}$/} onChange={onChange} />);
    const box = screen.getByLabelText('URN');
    fireEvent.change(box, { target: { value: '12345' } });
    expect(onChange).toHaveBeenLastCalledWith('12345', '12345');
    fireEvent.blur(box);
    expect(screen.getByRole('alert').textContent).toBe('Check the record number format');
  });
  it('passes validation through', () => {
    render(<PatientIdentifierInput region="NZ" defaultValue="ZAC5362" />);
    fireEvent.blur(screen.getByLabelText('NHI number'));
    expect(screen.getByRole('alert').textContent).toMatch(/not a valid NHI/);
  });
});
