import React from 'react';
import { useClinicalLocale } from '../../core';
import type { ClinicalRegion } from '../../core';
import { PATIENT_IDENTIFIER_FORM_LABELS, PRIMARY_IDENTIFIER_ORDER } from '../utils/regions/identifiers';
import type { PatientIdentifierType } from '../utils/regions/identifiers';
import { NhsNumberInput } from '../NhsNumberInput/NhsNumberInput';
import { IhiInput } from '../IhiInput/IhiInput';
import { MedicareNumberInput } from '../MedicareNumberInput/MedicareNumberInput';
import { DvaNumberInput } from '../DvaNumberInput/DvaNumberInput';
import { NhiInput } from '../NhiInput/NhiInput';
import { MRN_LABELS } from '../PatientIdentifierDisplay/PatientIdentifierDisplay';
import { IdentifierTextInput } from './IdentifierTextInput';

export interface PatientIdentifierInputProps {
  /** Identifier to enter. Default: the region's primary identifier (GB NHS Number, AU IHI, NZ NHI). */
  type?: PatientIdentifierType;
  /** Region. Default from `ClinicalLocaleProvider`. */
  region?: ClinicalRegion;
  /** Label. Default per type ("NHS Number", "IHI", "URN", "Medicare card number", "DVA file number", "NHI number"). */
  label?: string;
  /** Hint; "" for none. Default per control. */
  hint?: string;
  /** Controlled value. */
  value?: string;
  /** Uncontrolled initial value. */
  defaultValue?: string;
  /** Called with the value as shown and the normalised value (digits, or upper case for NHI and DVA). */
  onChange?: (shown: string, normalised: string) => void;
  /** Empty is an error once the field is left. Default false. */
  required?: boolean;
  /** Error from the consumer; overrides built-in validation. */
  error?: string;
  /** Called when built-in validity changes. */
  onValidityChange?: (valid: boolean) => void;
  /** Medicare only: controlled IRN, initial IRN and change handler (AU-ID-03). */
  irn?: string;
  defaultIrn?: string;
  onIrnChange?: (irn: string) => void;
  /** MRN only: local format check (AU-ID-04: format is organisation-configurable). */
  mrnPattern?: RegExp;
  /** MRN only: message when `mrnPattern` does not match. Default "Check the record number format". */
  mrnPatternMessage?: string;
  /** NZ only: warn for Z-range test NHIs. Default true. */
  flagTestNumbers?: boolean;
  disabled?: boolean;
  id?: string;
  className?: string;
}

/**
 * Picks the identifier control for the region and identifier type: NhsNumberInput, IhiInput, MedicareNumberInput,
 * DvaNumberInput, NhiInput, or a free-text local record number (URN/MRN) with an optional local pattern.
 */
export function PatientIdentifierInput({
  type: typeProp,
  region: regionProp,
  label,
  hint,
  value,
  defaultValue,
  onChange,
  required,
  error,
  onValidityChange,
  irn,
  defaultIrn,
  onIrnChange,
  mrnPattern,
  mrnPatternMessage = 'Check the record number format',
  flagTestNumbers,
  disabled,
  id,
  className,
}: PatientIdentifierInputProps) {
  const { region } = useClinicalLocale(regionProp);
  const type = typeProp ?? PRIMARY_IDENTIFIER_ORDER[region][0];
  const common = { id, className, disabled, required, error, onValidityChange, value, defaultValue };
  const withHint = hint === undefined ? {} : { hint };
  switch (type) {
    case 'nhs':
      return <NhsNumberInput {...common} {...withHint} label={label ?? PATIENT_IDENTIFIER_FORM_LABELS.nhs} onChange={onChange} />;
    case 'ihi':
      return <IhiInput {...common} {...withHint} label={label ?? PATIENT_IDENTIFIER_FORM_LABELS.ihi} onChange={onChange} />;
    case 'medicare':
      return (
        <MedicareNumberInput
          {...common}
          {...withHint}
          label={label ?? PATIENT_IDENTIFIER_FORM_LABELS.medicare}
          onChange={onChange}
          irn={irn}
          defaultIrn={defaultIrn}
          onIrnChange={onIrnChange}
        />
      );
    case 'dva':
      return <DvaNumberInput {...common} {...withHint} label={label ?? PATIENT_IDENTIFIER_FORM_LABELS.dva} onChange={(v) => onChange?.(v, v)} />;
    case 'nhi':
      return <NhiInput {...common} {...withHint} label={label ?? PATIENT_IDENTIFIER_FORM_LABELS.nhi} onChange={onChange} flagTestNumbers={flagTestNumbers} />;
    default:
      return (
        <IdentifierTextInput
          {...common}
          blockClass="cui-mrn-input"
          label={label ?? MRN_LABELS[region]}
          hint={hint || undefined}
          widthCh={14}
          sanitise={(raw) => ({ display: raw, normalised: raw.trim() })}
          normaliseOnBlur={(shown) => shown.trim()}
          validate={(v) => (!v ? (required ? `Enter the ${label ?? MRN_LABELS[region]}` : null) : mrnPattern && !mrnPattern.test(v) ? mrnPatternMessage : null)}
          isComplete={(v) => v.length > 0}
          onChange={onChange}
        />
      );
  }
}
