import React from 'react';
import { cx } from '../../core';
import { NZ_ETHNICITY_QUESTION, NZ_ETHNICITY_RESIDUAL_CODES } from '../utils/regions/demographics';
import { LabelledValue } from '../LabelledValue/LabelledValue';
import type { EthnicityValue } from '../EthnicityInput/EthnicityInput';

export interface EthnicityDisplayProps {
  /** Recorded ethnicities. Shown in the order recorded, never prioritised, none marked as main (HISO 10001; G11 4.1 display). */
  value: EthnicityValue | null | undefined;
  /** Label. Default "Ethnicity". */
  label?: string;
  /** Labels for codes that arrive without one (for example from a feed of codes only). */
  codeLabels?: Readonly<Record<string, string>>;
  /** Text when nothing is recorded. Default "Not recorded" [suggested: distinct from 99999 "Not stated"]. */
  unknownText?: string;
  /** "inline" or "stacked". Default "inline". */
  layout?: 'inline' | 'stacked';
  className?: string;
}

const KNOWN: Record<string, string> = Object.fromEntries(
  [...NZ_ETHNICITY_QUESTION.options, ...NZ_ETHNICITY_RESIDUAL_CODES].map((o) => [o.code, o.label]),
);

/**
 * Display texts for recorded ethnicities: standard and residual labels, then the person's own words for "Other" when given,
 * otherwise the coded "Other" labels. Order as recorded.
 */
export function ethnicityDisplayTexts(value: EthnicityValue | null | undefined, codeLabels: Readonly<Record<string, string>> = {}): string[] {
  if (!value) return [];
  const standard = new Set(Object.keys(KNOWN));
  const out: string[] = [];
  const otherTexts: string[] = [];
  for (const e of value.entries ?? []) {
    const label = e.label || codeLabels[e.code] || KNOWN[e.code] || e.code;
    if (standard.has(e.code)) out.push(KNOWN[e.code]);
    else otherTexts.push(label);
  }
  const own = (value.otherText ?? '').trim();
  return [...out, ...(own ? [own] : otherTexts)];
}

/** Labelled list of all recorded ethnicities (up to six), in recorded order, with macrons kept (HISO 10001). */
export function EthnicityDisplay({
  value,
  label = 'Ethnicity',
  codeLabels,
  unknownText = 'Not recorded',
  layout = 'inline',
  className,
}: EthnicityDisplayProps) {
  const texts = ethnicityDisplayTexts(value, codeLabels);
  const content = texts.length ? (
    <span className="cui-ethnicity-display__list">
      {texts.map((t, i) => (
        <React.Fragment key={i}>
          <span className="cui-ethnicity-display__item">
            {t}
            {i < texts.length - 1 ? ',' : ''}
          </span>
          {i < texts.length - 1 ? ' ' : null}
        </React.Fragment>
      ))}
    </span>
  ) : null;
  return <LabelledValue className={cx('cui-ethnicity-display', className)} label={label} value={content} unknownText={unknownText} layout={layout} noWrap={false} />;
}
