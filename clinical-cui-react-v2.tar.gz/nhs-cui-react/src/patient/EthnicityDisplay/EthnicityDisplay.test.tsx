import React from 'react';
import { describe, it, expect, afterEach } from 'vitest';
import { render, cleanup } from '@testing-library/react';
import { EthnicityDisplay, ethnicityDisplayTexts } from './EthnicityDisplay';

afterEach(cleanup);

describe('EthnicityDisplay', () => {
  it('all ethnicities in recorded order, none marked main (HISO 10001)', () => {
    const { container } = render(<EthnicityDisplay value={{ entries: [{ code: '31111', label: 'Samoan' }, { code: '21111', label: 'Māori' }] }} />);
    expect(container.textContent).toBe('Ethnicity Samoan, Māori');
  });
  it("uses the person's own words for Other", () => {
    expect(ethnicityDisplayTexts({ entries: [{ code: '11111', label: '' }, { code: '12948', label: 'Dutch' }], otherText: 'Frisian' })).toEqual([
      'New Zealand European',
      'Frisian',
    ]);
    expect(ethnicityDisplayTexts({ entries: [{ code: '12948', label: 'Dutch' }] })).toEqual(['Dutch']);
  });
  it('residuals and nothing recorded', () => {
    const { container, rerender } = render(<EthnicityDisplay value={{ entries: [{ code: '94444', label: '' }] }} />);
    expect(container.textContent).toBe("Ethnicity Don't know");
    rerender(<EthnicityDisplay value={null} />);
    expect(container.textContent).toBe('Ethnicity Not recorded');
  });
});
