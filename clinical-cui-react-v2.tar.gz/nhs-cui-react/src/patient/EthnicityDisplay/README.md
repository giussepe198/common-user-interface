# EthnicityDisplay

Labelled list of all recorded ethnicities in the order recorded, with none marked as main.

## When to use

- Patient summaries in NZ mode.

## What you provide

- `value` (`EthnicityValue` from `EthnicityInput`), `label` (default "Ethnicity"), `codeLabels` for codes that arrive without a label, `unknownText` (default "Not recorded").

```tsx
<EthnicityDisplay value={{ entries: [{ code: '21111', label: 'Māori' }, { code: '31111', label: 'Samoan' }] }} />
```

## Guidance implemented

- HISO 10001 [M]: all recorded ethnicities shown (up to six); none labelled main; macrons kept ("Māori", "Cook Islands Māori").
- G11 4.1 [UNCERTAIN]: shown in recorded order, not prioritised order, because prioritised order implies a principal ethnicity.
- [M] The person's own words are used for "Other" when given; otherwise the coded label.
- Residual codes shown in words ("Don't know", "Refused to answer" ...).

## Do and don't

- Don't sort by the prioritised output order on screen.

## Accessibility

- Plain text; items wrap only between groups.

## Regional behaviour

- NZ only.
