# InformationWindow

Non-modal window that explains a decision support recommendation or alert: summary, details, preference-ordered actions, "Record Response" and "Dismiss".

## When to use

- Opened from a preference icon in a choice list (variant "explanation"), or to show a single alert outside the alert container (variant "alert").

## What you provide

- `summaries` (text with record links, and the catalogue `source`), `details`, `actions` (same shape as `AlertItem` actions), `onRecordResponse`, `onDismiss`.

```tsx
<InformationWindow
  summaries={[{ text: <>Interaction with <a href="#meds">Furosemide</a></>, source: 'Drug Interaction Checking' }]}
  actions={[{ id: 'a', label: 'Reduce dose', preference: 5 }]}
  onRecordResponse={r => record(r)}
  onDismiss={close}
/>
```

## Guidance implemented

- 2.2: header, Summary and Details tabs with Summary selected and on the left; icon left of the summary; source in brackets; "Details…" link; Actions label with chevron, collapsed by default, hidden when there are none; actions most preferred first with a preference icon on the left and option buttons, sub-options as checkboxes ("and") or option buttons ("or"); "Record Response" then "Dismiss", always enabled; resize grip bottom right; fixed minimum size.
- 2.3: header "Explanation"; several summaries for one option share one window, actions consolidated.
- 2.4: alert variant header shows status, date and 24-hour time.
- [suggested] Esc dismisses; resizing uses the browser's resize handle.

## Do and don't

- Do link words derived from patient items to the item in its original context.
- Don't split summaries for one option across windows.
- Don't make it modal.

## Accessibility

- `role="dialog"` with `aria-modal="false"`, labelled by its header; focus moves to it on open (`autoFocus`).
- Tabs follow the tabs pattern (Left and Right arrows). The preference icons carry their level as text with reasons in a tooltip shown on focus.
- Resizing is pointer only [suggested: give users a size setting if they need it].

## Regional behaviour

No differences between GB, AU and NZ; G10 and G11 have no decision support display rules.
