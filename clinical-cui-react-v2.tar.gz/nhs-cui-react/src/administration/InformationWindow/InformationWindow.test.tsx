import React from 'react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { InformationWindow } from './InformationWindow';

afterEach(cleanup);

const summaries = [
  { text: 'There are potential additive hypotensive effects with Lisinopril and Furosemide', source: 'Drug Interaction Checking' },
  { text: 'Dose above the usual range for age', source: 'Dose Checking' },
];

describe('InformationWindow', () => {
  it('explanation header, Summary tab first, all summaries in one window with sources (2.2, 2.3)', () => {
    render(<InformationWindow summaries={summaries} onDismiss={vi.fn()} />);
    expect(screen.getByRole('heading', { name: 'Explanation' })).toBeTruthy();
    expect(screen.getByRole('tab', { name: 'Summary' }).getAttribute('aria-selected')).toBe('true');
    expect(screen.getByText('(Drug Interaction Checking)')).toBeTruthy();
    expect(screen.getByText('(Dose Checking)')).toBeTruthy();
    expect(screen.getByRole('dialog').getAttribute('aria-modal')).toBe('false');
  });

  it('hides Actions when there are none; Record Response before Dismiss, both enabled', () => {
    render(<InformationWindow summaries={summaries} />);
    expect(screen.queryByRole('button', { name: 'Actions' })).toBeNull();
    const buttons = screen.getAllByRole('button').map(b => b.textContent);
    expect(buttons.slice(-2)).toEqual(['Record Response', 'Dismiss']);
  });

  it('Details link and arrow keys switch tabs', () => {
    render(<InformationWindow summaries={summaries} details={{ rationale: 'Both lower blood pressure' }} />);
    fireEvent.click(screen.getByRole('button', { name: 'Details…' }));
    expect(screen.getByText('Both lower blood pressure')).toBeTruthy();
    fireEvent.keyDown(screen.getByRole('tab', { name: 'Details' }), { key: 'ArrowLeft' });
    expect(screen.getByRole('tab', { name: 'Summary' }).getAttribute('aria-selected')).toBe('true');
  });

  it('records the chosen action with or-type sub-options', () => {
    const onRecordResponse = vi.fn();
    render(
      <InformationWindow
        summaries={summaries}
        onRecordResponse={onRecordResponse}
        actions={[
          { id: 'a', label: 'Reduce dose', preference: 4, subOptions: [{ id: 'x', label: 'By half' }, { id: 'y', label: 'By a quarter' }], subOptionMode: 'or' },
          { id: 'b', label: 'Continue', preference: 1 },
        ]}
      />,
    );
    const toggle = screen.getByRole('button', { name: 'Actions' });
    expect(toggle.getAttribute('aria-expanded')).toBe('false');
    fireEvent.click(toggle);
    expect((screen.getByLabelText('By half') as HTMLInputElement).disabled).toBe(true);
    fireEvent.click(screen.getByLabelText('Reduce dose'));
    fireEvent.click(screen.getByLabelText('By half'));
    fireEvent.click(screen.getByLabelText('By a quarter'));
    fireEvent.click(screen.getByRole('button', { name: 'Record Response' }));
    expect(onRecordResponse).toHaveBeenCalledWith({ actionId: 'a', subOptionIds: ['y'] });
  });

  it('alert variant shows status, date and time; Esc dismisses', () => {
    const onDismiss = vi.fn();
    render(<InformationWindow variant="alert" status="High Priority" occurredAt={new Date(2026, 4, 27, 9, 5)} summaries={summaries} onDismiss={onDismiss} />);
    expect(screen.getByRole('heading').textContent).toBe('High Priority27-May-2026 09:05');
    fireEvent.keyDown(screen.getByRole('dialog'), { key: 'Escape' });
    expect(onDismiss).toHaveBeenCalled();
  });
});
