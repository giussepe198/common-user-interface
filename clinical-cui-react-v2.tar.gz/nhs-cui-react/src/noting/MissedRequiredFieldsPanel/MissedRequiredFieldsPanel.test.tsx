import React from 'react';
import { describe, it, expect, afterEach, vi } from 'vitest';
import { render, screen, fireEvent, cleanup } from '@testing-library/react';
import { MissedRequiredFieldsPanel } from './MissedRequiredFieldsPanel';
import { useRequiredFieldTracking } from './useRequiredFieldTracking';

afterEach(cleanup);

describe('MissedRequiredFieldsPanel', () => {
  it('lists all missed fields grouped by section with links (CNA-1210, CNA-1230)', () => {
    const onNavigate = vi.fn();
    render(<MissedRequiredFieldsPanel items={[{ id: 'a', label: 'Pulse', section: 'Observations' }, { id: 'b', label: 'Allergies', section: 'History' }]} onNavigate={onNavigate} />);
    expect(screen.getByRole('heading', { name: /Required fields/ })).toBeTruthy();
    expect(screen.getByText('2 required fields not completed.')).toBeTruthy();
    fireEvent.click(screen.getByRole('button', { name: 'Pulse' }));
    expect(onNavigate).toHaveBeenCalledWith('a');
  });
  it('renders nothing visible when nothing is missed', () => {
    const { container } = render(<MissedRequiredFieldsPanel items={[]} />);
    expect(container.querySelector('aside')).toBeNull();
  });
  it('tracks fields passed over while empty (CNA-1150)', () => {
    function Form() {
      const t = useRequiredFieldTracking([{ id: 'f1', label: 'Pulse', empty: true }, { id: 'f2', label: 'BP', empty: true }]);
      return (
        <div {...t.formProps}>
          <input id="f1" aria-label="Pulse" />
          <input id="f2" aria-label="BP" />
          <MissedRequiredFieldsPanel items={t.missedItems} onNavigate={() => undefined} />
        </div>
      );
    }
    render(<Form />);
    fireEvent.focus(screen.getByLabelText('BP'));
    expect(screen.getByRole('button', { name: 'Pulse' })).toBeTruthy();
  });
});
