import React from 'react';
import { describe, it, expect, vi, afterEach } from 'vitest';
import { render, screen, fireEvent, cleanup } from '@testing-library/react';
import { PathwayTimeline, type CarePathway } from './PathwayTimeline';

afterEach(cleanup);
const stage = (i: number, state: 'completed' | 'current' | 'future', extra = {}) => ({ id: `s${i}`, title: `Stage ${i}`, state, bundles: [], ...extra });
export const PATHWAY: CarePathway = {
  id: 'p1',
  title: 'Hip replacement',
  status: 'active',
  goal: 'Walking unaided',
  boundaries: [{ afterStageId: 's2', label: 'Handover to ward' }],
  stages: [
    stage(0, 'completed', { status: 'success' }),
    stage(1, 'completed', { status: 'failed', bundles: [{ id: 'b1', title: 'Pre-op bloods', state: 'failed' }] }),
    stage(2, 'completed', { status: 'success' }),
    stage(3, 'current', { team: 'Orthopaedics', targetTime: '2 days', actualTime: '3 days', targetMissed: true, bundles: [{ id: 'b2', title: 'Triage', state: 'completed', isKeyDecision: true, decision: 'Refer to surgery' }] }),
    stage(4, 'future'),
    stage(5, 'future'),
    stage(6, 'future'),
  ],
};

describe('PathwayTimeline', () => {
  it('opens previous, current and next stages and collapses the rest (all stages visible)', () => {
    render(<PathwayTimeline pathway={PATHWAY} />);
    expect(screen.getByRole('group', { name: /Stage C: Stage 2/ })).toBeTruthy();
    expect(screen.getByRole('group', { name: /Stage D: Stage 3\. Current stage/ })).toBeTruthy();
    expect(screen.getByRole('group', { name: /Stage E: Stage 4/ })).toBeTruthy();
    expect(screen.getByRole('button', { name: /Stage A: Stage 0.*Collapsed/ })).toBeTruthy();
    expect(screen.getByText('You are here')).toBeTruthy();
  });
  it('shows status with symbols and text, missed targets and key decisions in capitals', () => {
    render(<PathwayTimeline pathway={PATHWAY} />);
    expect(screen.getByText(/target 2 days \(missed\)/)).toBeTruthy();
    expect(screen.getByText('REFER TO SURGERY')).toBeTruthy();
    expect(screen.getByText(': key decision, Completed')).toBeTruthy();
    expect(screen.getByLabelText('Boundary of care: Handover to ward')).toBeTruthy();
  });
  it('moves focus with arrow keys, separately from the current stage', () => {
    const onFocus = vi.fn();
    render(<PathwayTimeline pathway={PATHWAY} onFocusChange={onFocus} />);
    const current = screen.getByRole('group', { name: /Current stage/ });
    fireEvent.keyDown(current, { key: 'ArrowRight' });
    expect(onFocus).toHaveBeenCalledWith('s4');
    fireEvent.keyDown(current, { key: 'Home' });
    expect(onFocus).toHaveBeenLastCalledWith('s0');
  });
  it('merges long runs into groups when over capacity', () => {
    render(<PathwayTimeline pathway={PATHWAY} capacity={5} />);
    expect(screen.getByRole('button', { name: /Stages A to [B-C], collapsed, includes a failed stage/ })).toBeTruthy();
  });
});
