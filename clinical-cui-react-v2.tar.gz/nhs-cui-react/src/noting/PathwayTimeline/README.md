# PathwayTimeline

Experimental. One care pathway as stages from left to right, showing where the patient is, what went right and what went wrong.

## When to use
- Showing a patient's progress along a care pathway. Built from a conceptual model with illustrative wireframes (Care Pathways, 2007): every rule is a conceptual design point.

## What you provide
- `pathway` (title, status, stages with bundles, optional boundaries, goal, precursor).
- Optional `focusId`/`onFocusChange`, `capacity` (default 9), `showBundles`.

```tsx
<PathwayTimeline pathway={hipReplacement} />
```

## Guidance implemented
- Left-to-right stages with start and goal markers; stages labelled A, B, C; all stages always visible without scroll bars: distant stages shrink to strips and long runs merge into composite blocks; at least the previous, current and next stages shown in detail.
- Current (blue keyline, "You are here") and focus (focus outline, moved with arrow keys or a click) are different.
- Status by symbol and colour: tick success, cross failed, warning; bundles with tick, cross, bullet for future or not attempted, bold for active; a flag for key decisions with the following action in bold capitals.
- Targets: actual and target time, missed targets in a distinct style with an icon.
- Boundaries of care as dotted separators with a label and arrow; stage groups ("Day of operation") as non-interactive markers.
- Details on hover and on focus in a line under the pathway.
- Not built: sub-pathways, resizable split, cyclical diagrams (`CarePathwayCycle`).

## Do and don't
- Do keep bundle titles short.
- Don't use it as a Gantt chart: sequence matters more than time.

## Accessibility
- Stages are an ordered list; each stage is focusable with a name stating its letter, title, state and status; Left, Right, Home and End move the focus; strips and groups are buttons that open them.
