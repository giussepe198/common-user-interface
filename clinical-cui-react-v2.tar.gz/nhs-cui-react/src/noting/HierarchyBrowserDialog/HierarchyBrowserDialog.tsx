import React from 'react';
import { Button, cx, useClinicalLocale, useId, type ClinicalRegion } from '../../core';
import { ModalFrame } from '../internal/ModalFrame';
import { termCollator } from '../utils/searchText';

/** A concept in the hierarchy browser. The id is never displayed (SCT-044). */
export interface HierarchyConcept {
  id: string;
  /** Display term (preferred term in the region's language reference set), macrons kept. */
  term: string;
}

type Lookup = (id: string) => Promise<HierarchyConcept[]> | HierarchyConcept[];

export interface HierarchyBrowserDialogProps {
  /** Concept to start from. */
  concept: HierarchyConcept;
  /** Less specific concepts (parents). */
  getParents: Lookup;
  /** More specific concepts (children). */
  getChildren: Lookup;
  /** Siblings: other children of all the parents. */
  getSiblings: Lookup;
  /** Limit what can be chosen (e.g. sanctioned post-coordination values). Others are shown but cannot be selected. */
  canSelect?: (c: HierarchyConcept) => boolean;
  /** The concept is negated ("No ..."): browsing is not offered (Post-coordination 2.1.2). */
  negated?: boolean;
  /** Chosen concept. */
  onOk: (concept: HierarchyConcept) => void;
  onCancel: () => void;
  /** Dialog title. Default "Browse related concepts". */
  title?: string;
  /** Jurisdiction for sorting (ā sorts with a in NZ). Default from `ClinicalLocaleProvider`. */
  region?: ClinicalRegion;
  /** Render in place instead of as a modal overlay (for previews or a host dialog). */
  inline?: boolean;
}

interface Lists {
  parents: HierarchyConcept[];
  siblings: HierarchyConcept[];
  children: HierarchyConcept[];
}

/**
 * Modal hierarchy browser (Matching 2.5.1, SCT-058): three alphabetical lists from left to right,
 * less specific, similar and more specific concepts. Choosing a concept re-centres the lists on it;
 * double-click, or Select then OK, chooses it. A Back button returns to the previous concept.
 */
export function HierarchyBrowserDialog({
  concept,
  getParents,
  getChildren,
  getSiblings,
  canSelect,
  negated = false,
  onOk,
  onCancel,
  title = 'Browse related concepts',
  region: regionProp,
  inline,
}: HierarchyBrowserDialogProps) {
  const { region } = useClinicalLocale(regionProp);
  const baseId = useId('cui-hier');
  const [history, setHistory] = React.useState<HierarchyConcept[]>([concept]);
  const centre = history[history.length - 1];
  const [lists, setLists] = React.useState<Lists | null>(null);
  const [status, setStatus] = React.useState('');
  const collator = React.useMemo(() => termCollator(region), [region]);

  React.useEffect(() => {
    if (negated) return;
    let live = true;
    setLists(null);
    setStatus('Loading related concepts');
    const sort = (xs: HierarchyConcept[]) => [...xs].sort((a, b) => collator.compare(a.term, b.term));
    Promise.all([getParents(centre.id), getSiblings(centre.id), getChildren(centre.id)]).then(
      ([p, s, c]) => {
        if (!live) return;
        setLists({ parents: sort(p), siblings: sort(s.filter((x) => x.id !== centre.id)), children: sort(c) });
        setStatus(`${centre.term}: ${p.length} less specific, ${c.length} more specific concepts`);
      },
      () => live && setStatus('Related concepts could not be loaded.'),
    );
    return () => {
      live = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [centre.id, negated]);

  const recentre = (c: HierarchyConcept) => setHistory((h) => [...h, c]);
  const selectable = (c: HierarchyConcept) => (canSelect ? canSelect(c) : true);

  const column = (key: keyof Lists, heading: string) => (
    <section className="cui-hierarchy__column" aria-labelledby={`${baseId}-${key}`}>
      <h3 id={`${baseId}-${key}`} className="cui-hierarchy__heading">{heading}</h3>
      {lists ? (
        lists[key].length ? (
          <ul className="cui-hierarchy__list">
            {lists[key].map((c) => (
              <li key={c.id}>
                <button
                  type="button"
                  className={cx('cui-hierarchy__item', !selectable(c) && 'cui-hierarchy__item--blocked')}
                  title={selectable(c) ? 'Show related concepts. Double-click to choose.' : 'Cannot be chosen here'}
                  onClick={() => recentre(c)}
                  onDoubleClick={() => selectable(c) && onOk(c)}
                >
                  {c.term}
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <p className="cui-hierarchy__empty">None</p>
        )
      ) : (
        <p className="cui-hierarchy__empty">Loading</p>
      )}
    </section>
  );

  return (
    <ModalFrame labelledBy={`${baseId}-title`} onEscape={onCancel} inline={inline} className="cui-hierarchy">
      <h2 id={`${baseId}-title`} className="cui-noting-modal__title">{title}</h2>
      {negated ? (
        <p>Related concepts cannot be browsed for a term recorded as absent.</p>
      ) : (
        <>
          <div className="cui-hierarchy__selected">
            <label htmlFor={`${baseId}-selected`} className="cui-hierarchy__selected-label">Selected</label>
            <output id={`${baseId}-selected`} className="cui-hierarchy__selected-term">{centre.term}</output>
            <Button size="sm" variant="quiet" icon="chevron-left" disabled={history.length < 2} onClick={() => setHistory((h) => h.slice(0, -1))}>
              Back
            </Button>
          </div>
          <div className="cui-hierarchy__columns">
            {column('parents', 'Less specific concepts')}
            {column('siblings', 'Similar concepts')}
            {column('children', 'More specific concepts')}
          </div>
          <p className="cui-prompt cui-hierarchy__help">Choose a concept to see its related concepts. Double-click a concept, or choose it and select OK, to use it.</p>
        </>
      )}
      <span className="cui-visually-hidden" aria-live="polite">{status}</span>
      <div className="cui-noting-modal__actions">
        <Button onClick={onCancel}>Cancel</Button>
        {!negated ? (
          <Button variant="primary" disabled={!selectable(centre)} onClick={() => onOk(centre)}>
            OK
          </Button>
        ) : null}
      </div>
    </ModalFrame>
  );
}
