# HierarchyBrowserDialog

A modal dialog for browsing related concepts: less specific, similar and more specific.

## When to use
- From "Browse for related concepts" in `ConceptFlyout` when the user wants a more or less specific concept.

## What you provide
- `concept`, `getParents`, `getSiblings`, `getChildren` (each returns a list or a promise), `onOk`, `onCancel`.
- Optional `canSelect` (limit choices, e.g. sanctioned post-coordination values), `negated`, `title`, `region`, `inline`.

```tsx
<HierarchyBrowserDialog concept={{ id, term }} getParents={parents} getSiblings={siblings} getChildren={children}
  onOk={choose} onCancel={close} />
```

## Guidance implemented
- Matching 2.5.1 (low confidence) and G8 HierarchyBrowserDialog: modal; three labelled lists from left to right ("Less specific concepts", "Similar concepts", "More specific concepts"), each alphabetical; a "Selected" field; single click re-centres the lists; double-click chooses and closes; "Back" returns to the previous concept.
- Disabled for negated concepts (Post-coordination 2.1.2: no browsing of a known-absent finding).
- Concept identifiers are never shown (SCT-044).
- Not built: attribute tabs for refining defining attributes.

## Do and don't
- Do return display terms from the region's language reference set.
- Don't use it as the main way to find a concept; search first.

## Accessibility
- Modal dialog with focus kept inside, Escape to cancel and focus returned on close.
- Each concept is a button; OK chooses the concept in the "Selected" field, so double-click is never required.
- A polite live region reports what was loaded.

## Regional behaviour
- Lists are sorted with the region's collator, so in NZ "Ōtaki" sorts with O and "Āwhina" with A (G11 11.1).
