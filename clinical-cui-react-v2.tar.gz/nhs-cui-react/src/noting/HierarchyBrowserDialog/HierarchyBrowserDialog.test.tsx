import React from 'react';
import { describe, it, expect, vi, afterEach } from 'vitest';
import { render, screen, fireEvent, cleanup, within } from '@testing-library/react';
import { HierarchyBrowserDialog, type HierarchyConcept } from './HierarchyBrowserDialog';

afterEach(cleanup);

const C: Record<string, HierarchyConcept> = {
  asthma: { id: 'asthma', term: 'Asthma' },
  lung: { id: 'lung', term: 'Disorder of lung' },
  airway: { id: 'airway', term: 'Airway disease' },
  copd: { id: 'copd', term: 'Chronic obstructive lung disease' },
  aa: { id: 'aa', term: 'Allergic asthma' },
  ea: { id: 'ea', term: 'Exercise-induced asthma' },
};
const parents = (id: string) => (id === 'asthma' ? [C.lung, C.airway] : id === 'aa' ? [C.asthma] : []);
const children = (id: string) => (id === 'asthma' ? [C.ea, C.aa] : []);
const siblings = (id: string) => (id === 'asthma' ? [C.copd, C.asthma] : []);

describe('HierarchyBrowserDialog', () => {
  it('lists less specific, similar and more specific concepts alphabetically (Matching 2.5.1)', async () => {
    render(<HierarchyBrowserDialog concept={C.asthma} getParents={parents} getChildren={children} getSiblings={siblings} onOk={vi.fn()} onCancel={vi.fn()} />);
    await screen.findByRole('button', { name: 'Allergic asthma' });
    const more = screen.getByText('More specific concepts').closest('section')!;
    const items = within(more).getAllByRole('button').map((b) => b.textContent);
    expect(items).toEqual(['Allergic asthma', 'Exercise-induced asthma']);
    expect(screen.getByRole('dialog').getAttribute('aria-modal')).toBe('true');
  });
  it('re-centres on click, goes Back, and chooses with OK or double-click', async () => {
    const onOk = vi.fn();
    render(<HierarchyBrowserDialog concept={C.asthma} getParents={parents} getChildren={children} getSiblings={siblings} onOk={onOk} onCancel={vi.fn()} />);
    fireEvent.click(await screen.findByRole('button', { name: 'Allergic asthma' }));
    expect(document.querySelector('output')?.textContent).toBe('Allergic asthma');
    fireEvent.click(screen.getByRole('button', { name: 'Back' }));
    expect(document.querySelector('output')?.textContent).toBe('Asthma');
    fireEvent.doubleClick(await screen.findByRole('button', { name: 'Exercise-induced asthma' }));
    expect(onOk).toHaveBeenCalledWith(C.ea);
  });
  it('Escape cancels; browsing is not offered for negated concepts', () => {
    const onCancel = vi.fn();
    render(<HierarchyBrowserDialog negated concept={C.asthma} getParents={parents} getChildren={children} getSiblings={siblings} onOk={vi.fn()} onCancel={onCancel} />);
    expect(screen.getByText(/cannot be browsed/)).toBeTruthy();
    fireEvent.keyDown(screen.getByRole('dialog'), { key: 'Escape' });
    expect(onCancel).toHaveBeenCalled();
  });
  it('NZ sorts macron vowels with their base letter', async () => {
    const kids = () => [{ id: '1', term: 'Ōtaki case' }, { id: '2', term: 'Nelson case' }, { id: '3', term: 'Ahuriri case' }];
    render(<HierarchyBrowserDialog region="NZ" concept={C.asthma} getParents={() => []} getChildren={kids} getSiblings={() => []} onOk={vi.fn()} onCancel={vi.fn()} />);
    await screen.findByRole('button', { name: 'Ahuriri case' });
    const sec = screen.getByText('More specific concepts').closest('section')!;
    expect(within(sec).getAllByRole('button').map((b) => b.textContent)).toEqual(['Ahuriri case', 'Nelson case', 'Ōtaki case']);
  });
});
